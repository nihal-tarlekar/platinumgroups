// about 1
$(document).ready(function(){
    $('#slider-1').click(function(e) {
    $('#sign_up').lightbox_me({
    centered: true, 
    onLoad: function() { 
    $('#sign_up').find('input:first').focus()
    }
    });
    e.preventDefault();
    });

    $ele.lightbox_me();
    $ele.trigger('close');
})
// 2
$(document).ready(function(){
    $('#slider-2').click(function(e) {
    $('#sign_up-1').lightbox_me({
    centered: true, 
    onLoad: function() { 
    $('#sign_up-1').find('input:first').focus()
    }
    });
    e.preventDefault();
    });

    $ele.lightbox_me();
    $ele.trigger('close');
})
// 3
$(document).ready(function(){
    $('#slider-3').click(function(e) {
    $('#sign_up-2').lightbox_me({
    centered: true, 
    onLoad: function() { 
    $('#sign_up-2').find('input:first').focus()
    }
    });
    e.preventDefault();
    });

    $ele.lightbox_me();
    $ele.trigger('close');
})
// 4
$(document).ready(function(){
    $('#slider-4').click(function(e) {
    $('#sign_up-3').lightbox_me({
    centered: true, 
    onLoad: function() { 
    $('#sign_up-3').find('input:first').focus()
    }
    });
    e.preventDefault();
    });

    $ele.lightbox_me();
    $ele.trigger('close');
})
// 5
$(document).ready(function(){
    $('#slider-5').click(function(e) {
    $('#sign_up-4').lightbox_me({
    centered: true, 
    onLoad: function() { 
    $('#sign_up-4').find('input:first').focus()
    }
    });
    e.preventDefault();
    });

    $ele.lightbox_me();
    $ele.trigger('close');
})
// 6
$(document).ready(function(){
    $('#slider-6').click(function(e) {
    $('#sign_up-5').lightbox_me({
    centered: true, 
    onLoad: function() { 
    $('#sign_up-5').find('input:first').focus()
    }
    });
    e.preventDefault();
    });

    $ele.lightbox_me();
    $ele.trigger('close');
})
// 7
$(document).ready(function(){
    $('#slider-7').click(function(e) {
    $('#sign_up-6').lightbox_me({
    centered: true, 
    onLoad: function() { 
    $('#sign_up-6').find('input:first').focus()
    }
    });
    e.preventDefault();
    });

    $ele.lightbox_me();
    $ele.trigger('close');
})
// 8
$(document).ready(function(){
    $('#slider-8').click(function(e) {
    $('#sign_up-7').lightbox_me({
    centered: true, 
    onLoad: function() { 
    $('#sign_up-7').find('input:first').focus()
    }
    });
    e.preventDefault();
    });

    $ele.lightbox_me();
    $ele.trigger('close');
})
// cutsection 1
$(document).ready(function(){
    $('#cut-image').click(function(e) {
    $('#sign_up-8').lightbox_me({
    centered: true, 
    onLoad: function() { 
    $('#sign_up-8').find('input:first').focus()
    }
    });
    e.preventDefault();
    });

    $ele.lightbox_me();
    $ele.trigger('close');
})
// 2
$(document).ready(function(){
    $('#cut-image-1').click(function(e) {
    $('#sign_up-9').lightbox_me({
    centered: true, 
    onLoad: function() { 
    $('#sign_up-9').find('input:first').focus()
    }
    });
    e.preventDefault();
    });

    $ele.lightbox_me();
    $ele.trigger('close');
})
// 3
$(document).ready(function(){
    $('#cut-image-2').click(function(e) {
    $('#sign_up-10').lightbox_me({
    centered: true, 
    onLoad: function() { 
    $('#sign_up-10').find('input:first').focus()
    }
    });
    e.preventDefault();
    });

    $ele.lightbox_me();
    $ele.trigger('close');
})


// general inquery
$(document).ready(function(){
    $('#general-inq').click(function(e) {
    $('#sign_up-11').lightbox_me({
    centered: true, 
    onLoad: function() { 
    $('#sign_up-11').find('input:first').focus()
    }
    });
    e.preventDefault();
    });

    $ele.lightbox_me();
    $ele.trigger('close');
})