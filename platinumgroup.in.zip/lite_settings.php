<?

$email_to ="nihal@optimist.co.in"; 
$email_subject = "Enquiry Form"; // email subject line
$thankyou = "thank-you.html"; // thank you page

?>



